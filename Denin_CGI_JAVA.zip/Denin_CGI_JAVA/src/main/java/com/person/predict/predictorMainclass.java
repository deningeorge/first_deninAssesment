// Main class of the program, starting point, RUN THIS !!!!
// by Denin George
// this is a console based program
package com.person.predict;

import java.util.Scanner;

public class predictorMainclass {

	public static void main(String[] args) {
     try {
    	 Scanner in = new Scanner(System.in);
    	 System.out.print("Enter the name: ");
    	 String name = in.nextLine();    	 
    	 in.close();
    	   
    	 PredictService predictService  = new PredictService();
    	 if(!name.trim().isEmpty()) {
    		 Person person  = predictService.getPersonDetails(name);
			 if(person.getAge() == 0 && person.getGender() == null) {
				 System.out.println("Invalid name given please check !!");
			 }
			 else {
				 System.out.println("Prediction: "+person.toString() );
			 }
        	 
    	 }else
    		 System.out.println("Invalid name given please check !!");
    	 
    	 
    } catch (Exception e) {
        System.out.println("Exception in NetClientGet:- " + e);
    }

	}
}
