// by Denin George
// this is the service class where the main operations in question are carried out
package com.person.predict;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.google.gson.Gson;

public class PredictService {
	public Person getPersonDetails(String name) {
		Person person = new Person();
		person.setName(name);
		person.setAge(getAge(person));
		person.setGender(getGender(person));
		return person;
	}


	public int getAge(Person person) {   // method to get age by using the given API in question
        int age = 0;
		person = getApiCall("https://api.agify.io?name=" + person.getName());
		if(person!=null) {
			age  = person.getAge();
		}
		return age;

	}

	public String getGender(Person person) {   //  method to get gender by using the given API in question
         String gender="";
		person = getApiCall("https://api.genderize.io/?name=" + person.getName());
		if(person!=null) {
			gender = person.getGender();
			
		}
		return gender;
	}

	public Person getApiCall(String urlStr) {   // to establish connection and get response from given url
		Person response = null;
		try {
			URL url = new URL(urlStr);// your url i.e fetch data from .
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			if (conn.getResponseCode() != 200) {
				System.out.println("Failed : HTTP Error code : " + conn.getResponseCode());
			}else {
				InputStreamReader in = new InputStreamReader(conn.getInputStream());
				BufferedReader br = new BufferedReader(in);
				String output = "";
				output = br.readLine();

				conn.disconnect();

				Gson g = new Gson();

				response = g.fromJson(output, Person.class);
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
	}

}
